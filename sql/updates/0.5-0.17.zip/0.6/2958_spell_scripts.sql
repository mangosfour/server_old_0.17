ALTER TABLE `spell_scripts`
  CHANGE COLUMN `datatext` `datatext` text NOT NULL;
