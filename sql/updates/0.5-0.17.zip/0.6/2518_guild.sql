ALTER TABLE `guild`
  ADD `info` TEXT NOT NULL AFTER `BackgroundColor` ;
