ALTER TABLE `creature_grid`   ENGINE = MEMORY;
