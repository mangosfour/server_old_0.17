ALTER TABLE `gameobject_template`
    DROP `castsSpell`;
