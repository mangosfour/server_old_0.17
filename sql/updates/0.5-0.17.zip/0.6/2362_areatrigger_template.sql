ALTER TABLE `areatrigger_template`
    CHANGE `trigger_postion_x` `trigger_position_x` FLOAT NOT NULL DEFAULT '0';
