ALTER TABLE `quest_template`
  ADD `ExclusiveGroup` int(11) unsigned NOT NULL default '0' AFTER `NextQuestId`;
