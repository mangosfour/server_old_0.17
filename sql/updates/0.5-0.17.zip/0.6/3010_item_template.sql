ALTER TABLE `item_template` ADD COLUMN `BagFamily` tinyint(3) unsigned NOT NULL default '0' AFTER `area`;
