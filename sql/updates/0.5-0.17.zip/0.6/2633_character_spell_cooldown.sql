ALTER TABLE `character_spell_cooldown`
  CHANGE `time` `time` bigint(20) unsigned NOT NULL default '0';
