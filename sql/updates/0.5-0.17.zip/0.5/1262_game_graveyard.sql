ALTER TABLE `game_graveyard` RENAME TO `areatrigger_graveyard`;
