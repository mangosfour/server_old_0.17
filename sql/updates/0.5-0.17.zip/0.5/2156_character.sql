ALTER TABLE `character`
    ADD `totaltime` int(11) unsigned NOT NULL default '0',
    ADD `leveltime` int(11) unsigned NOT NULL default '0';
