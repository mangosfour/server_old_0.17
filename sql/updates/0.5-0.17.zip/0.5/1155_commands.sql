ALTER TABLE `command` CHANGE `help` `help` LONGTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
