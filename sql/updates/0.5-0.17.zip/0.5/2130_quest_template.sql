ALTER TABLE `quest_template`
    CHANGE `RewRepValue1` `RewRepValue1` int(11) NOT NULL default '0',
    CHANGE `RewRepValue2` `RewRepValue2` int(11) NOT NULL default '0';
