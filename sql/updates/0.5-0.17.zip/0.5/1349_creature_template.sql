ALTER TABLE `creature_template`
    DROP KEY `entry` ,
    ADD PRIMARY KEY (`entry`) ;
