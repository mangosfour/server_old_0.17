ALTER TABLE `character_spell`
    ADD `active` int(11) unsigned NOT NULL default '1';
