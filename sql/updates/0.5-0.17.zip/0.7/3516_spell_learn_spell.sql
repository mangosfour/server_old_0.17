insert  into `spell_learn_spell`(`entry`,`SpellID`,`IfNoSpell`) values (25229,25255,0);
insert  into `spell_learn_spell`(`entry`,`SpellID`,`IfNoSpell`) values (25229,25493,0);
insert  into `spell_learn_spell`(`entry`,`SpellID`,`IfNoSpell`) values (25229,26925,0);
insert  into `spell_learn_spell`(`entry`,`SpellID`,`IfNoSpell`) values (25229,32259,0);
