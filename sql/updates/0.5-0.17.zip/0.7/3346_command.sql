UPDATE `command` SET `name`='lookupobject' WHERE `name`='.lookupobject';
UPDATE `command` SET `name`='listcreature' WHERE `name`='.listcreature';
UPDATE `command` SET `name`='listobject'   WHERE `name`='.listobject';
UPDATE `command` SET `name`='listitem'     WHERE `name`='.listitem';
