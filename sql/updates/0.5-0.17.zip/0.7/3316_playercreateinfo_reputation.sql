DROP TABLE IF EXISTS `playercreateinfo_reputation`;
